RTL_LABS_3_4 - Verilog Solutions
================================

This folder contains one synthesizable Verilog implementation per lab
described in RTL_LABS_3_4.pdf.

Chapter 3
---------
lab3_1_mux8to1.v          Lab 3-1: 8-to-1 mux (5-bit wide, 3-bit select)
lab3_2_comparator_rel.v   Lab 3-2: 8-bit relational comparator (EQ/GT/LT)
lab3_3_dec3to8.v          Lab 3-3: 3-to-8 decoder w/ enable
                          (module name "3to8dec" is an escaped Verilog
                          identifier since names can't start with a digit)
lab3_4_count_ones.v       Lab 3-4: population count + index of first '1'
lab3_6_parity_gen.v       Lab 3-6: 32-bit data parity generator
                          (4 parity bits, one per byte, in bits [35:32])
lab3_6_mult3.v            Lab 3-6: multiply-by-3 without the '*' operator
lab3_barrel_shifter.v     Barrel shifter example (barrel_org) shown in the
                          "Adder And Barrel Shifter" slide, transcribed as
                          given (see in-file note about a bit-width
                          inconsistency in the original slide source)
lab3_alu.v                Lab 3-1 (ALU chapter): 32-bit ALU supporting
                          ADD/SUB/AND/OR/XOR/SHR/SHL/barrel-rotate

Chapter 4
---------
lab4_1_sync_sc_ff.v       Lab 4-1: sync_sc_ff (set/clear flop) plus the
                          companion 8-bit clear/set(16)/count-down counter
                          described on the same slide
lab4_2_updown_counter.v   Lab 4-2: 8-bit up/down counter
lab4_3_majority_voter.v   Lab 4-3: serial input majority voter (3-sample
                          sliding-window majority)
lab4_4_serializer.v       Lab 4-4: 8-bit to 1-bit serializer
lab4_5_edge_detector.v    Lab 4-5: positive/negative edge counter
lab4_6_seq_detector.v     Lab 4-6: 0110/0101 sequence detector (FSM)
lab4_7_regfile.v          Lab 4-7: 16x8 register file
lab4_8_fifo.v             Lab 4-8: 128-entry x 8-bit FIFO
                          (a "reset" input was added to the port list;
                          the slide's port list omitted one, but pointers
                          need an initial value)

lab4_9a_uart_rx.v         Lab 4-9: UART serial-to-parallel receiver
lab4_9b_uart_tx.v         Lab 4-9: UART parallel-to-serial transmitter
lab4_9c_dual_port_mem.v   Lab 4-9: 2-port memory model (1 read, 1 write port)
lab4_9d_uart_top.v        Lab 4-9: top-level integration tying the above
                          together with two instances of the Lab 4-8 fifo
                          module (one for inbound commands, one for
                          outbound responses) and a simple command FSM.
                          The exact UART frame format wasn't specified in
                          the slides, so a simple illustrative protocol is
                          used (see comments in the file).

Notes
-----
- Several labs only give a module port list/skeleton in the slides (body
  left as "..." or "//logic here"); this package provides a complete,
  reasonable implementation for each based on the stated objective and
  specification.
- Where a slide's port list appeared incomplete or inconsistent (e.g. the
  Lab 4-8 fifo module, or the barrel shifter bit widths), this is called
  out in a comment in the corresponding file rather than silently changed.
